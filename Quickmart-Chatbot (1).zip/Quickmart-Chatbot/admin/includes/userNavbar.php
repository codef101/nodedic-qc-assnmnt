      <div id="head">
            <div>
            <a href="logout.php" style="text-decoration: none;font-size:30px;color:greenyellow;float:right;">Logout</a>
            <h1>Welcome <?php echo $_SESSION['Email']; ?> this is Your Dashboard</h1>
      </div>
      
<div id="home">
<p>Welcome to Quickmart Supermarket</P>
</div>
          
      