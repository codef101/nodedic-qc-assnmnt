<?php

class Role{
    public static $admin=1;
    public static $user=2;
}
?>